#include<stdio.h>
#include<math.h>

void cvtGray(struct ppmimg *src, struct ppmimg *dst, char *name);
unsigned char roundAngle(int angle);

